package com.example.firebase;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import com.google.firebase.messaging.FirebaseMessagingException;

@Component
public class NotificationScheduler {

    private final FirebaseNotificationService firebaseService;

    public NotificationScheduler(FirebaseNotificationService firebaseService) {
        this.firebaseService = firebaseService;
    }

    @Scheduled(fixedRate = 3600000)
    public void sendNotificationHourly() {
        try {
            firebaseService.sendToToken();
        } catch (FirebaseMessagingException e) {
            e.printStackTrace();
        }
    }
}
