package com.grupo.rentahouse.rent_a_house

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
