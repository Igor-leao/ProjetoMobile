import 'package:flutter/material.dart';
import 'package:rent_a_house/myapp.dart';

void main() {
  runApp(MyApp());
}
