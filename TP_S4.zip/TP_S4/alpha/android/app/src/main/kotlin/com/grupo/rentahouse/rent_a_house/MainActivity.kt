package com.grupo.rentahouse.rent_a_house

//import io.flutter.embedding.android.FlutterActivity

//class MainActivity : FlutterActivity()

import io.flutter.embedding.android.FlutterFragmentActivity

class MainActivity: FlutterFragmentActivity() {
    // ...
}